/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.html', './src/**/*.js'],
  theme: {
    screens: {
      sm: '640px',
      md: '768px',
      lg: '1024px',
      xl: '1280px',
      xlmedia: '1750px',
      xxl: '1920px',
    },
    container: {
      center: true,
      padding: {
        DEFAULT: '13px',
        xl: '30px',
        xxl: '0px',
      },
      screens: {
        xl: '1280px',
        xxl: '1794px',
      },
    },
    fontSize: {
      titleH1: ['22px', '115%'],
      textContent: ['14px', '145%'],
      textNum: ['68.05px', '145%'],
    },
    extend: {
      colors: {
        bgHero: '#000000',
        subHeader: '#EFEFEF',
      },
      backgroundImage: {
        bgHero: "url('images/bg-hero.jpg')",
        bgHeroProducts: "url('images/product/hero-product.jpg')",
        bgHeroTraining: "url('images/training//hero-training.jpg')",

        bgSlide1: "url('images/slider/bg-slide1.jpg')",
      },
    },
  },
  plugins: [],
};
